=====================================================================
Title:    NecroQuest

Subtitle: The Inheritance, Chapter-1

Version:  V1.00

Updated:  July 10, 2008

License: 

This game is freeware. You are allowed to play, copy and redistribute it as much as you like, but you're not allowed to sell or change it.

If you want to use some parts of it somehow, please contact me for permission. It will be usually granted.

This  game  is  distributed in the hope that it will  be  useful, but WITHOUT   ANY   WARRANTY.   


Copyright (c) 2006 by Yarooze
---------------------------------------------------------------------

1 Disclaimer


This  game is a work of fiction.  Names, characters, places, and incidents are the product of the author's  imagination or are used fictitiously, and any resemblance to actual persons, living, dead or living dead, business establishments, events, or locales is entirely coincidental.

This game contains adult oriented material (for example of a graphic and sexual nature or violence), and may be objectionable to some persons. This material is intended for adult persons (over 14, 16, 18, 21, 86 years of age or whatever your government and/or religion say), and may be against the law in some areas. If you are accessing this area from any location that deems this type of material to be illegal, don't play this game.


2 Credits


   Developers:
   ==================================================================
   Yarooze - everything - (yarooze.blogspot.com)
   dunnoson - betatest, advanced proofreading
   spire8989 - betatest
   700 - betatest   


   Contributors: (engine, templates, etc)
   ==================================================================
   Chris Jones - AGS Engine - (http://www.bigbluecup.com)
   BuRRe - BASS-Template - (burre@mds.mdh.se) 



   Special Thanks: (participated in project) 
   ==================================================================
   D�P - "Regen" song performance
   Fawfulhasfury - first fanart
   AGS-community - (^_^) - (http://www.adventuregamestudio.co.uk/forum/)


I also used some free FX sounds, downloaded from internet. On the pages, where I found them, I read, that the are free. But if you are the author, and you don't  want to give me a permission to use them, PM me in the AGS forum. I'll fix it. (http://www.adventuregamestudio.co.uk/forum/)


There are also some documents in the DOCS folder. 


3 Installation

This game is distributed as a compressed ZIP file.  To install the game the distribution file should be unzipped to a folder you wish (usually My Documents or something like that). Run winsetup.exe, to configure the game for your computer hardware and/or language.  

Enjoy... 



Yarooze

